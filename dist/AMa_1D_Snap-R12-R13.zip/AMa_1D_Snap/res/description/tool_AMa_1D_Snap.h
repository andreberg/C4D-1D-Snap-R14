#ifndef _Antosha_Marchenko_1D_Snap_H_
#define _Antosha_Marchenko_1D_Snap_H_
enum
{
AMa_1DSNAP_TO_INVIS	=3000,
AMa_1DSNAP_AX,
AMa_1DSNAP_LINK,
AMa_1DSNAP_GR1,
AMa_1DSNAP_AX_GLOB	=1,
AMa_1DSNAP_AX_LOCAL,
AMa_1DSNAP_AX_ROOT,
AMa_1DSNAP_AX_PARE,
AMa_1DSNAP_AX_CAM,
AMa_1DSNAP_AX_FROM_O,
AMa_1DSNAP_AX_FREE,
_N
};
#endif